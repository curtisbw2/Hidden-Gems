"""Hidden Gems Discord Bot."""
